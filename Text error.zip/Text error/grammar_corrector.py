import language_tool_python


class GrammarCorrector:
    def __init__(self):
        try:
            self.tool = language_tool_python.LanguageTool('en-US')  # Initialize self.tool
            print("LanguageTool initialized successfully!")
        except Exception as e:
            print(f"Error initializing LanguageTool: {e}")
            raise

    def correct(self, text):
        try:
            # Step 1: Preprocessing (fix known issues before correction)
            text = self.preprocess_text(text)

            # Step 2: Detect grammar issues
            matches = self.tool.check(text)  # Use self.tool

            # Step 3: Apply corrections
            corrected_text = language_tool_python.utils.correct(text, matches)

            # Step 4: Post-processing (handle missed or incorrect replacements)
            corrected_text = self.postprocess_text(corrected_text)

            # Collect detailed error information
            errors = []
            for match in matches:
                errors.append({
                    'message': match.message,
                    'context': match.context,
                    'suggestions': match.replacements,
                    'offset': match.offset,
                    'length': match.errorLength
                })

            return corrected_text, errors

        except Exception as e:
            print(f"Error during grammar correction: {e}")
            raise

    def preprocess_text(self, text):
        # Handle known common errors
        text = text.replace("gramer", "grammar")  # Fix "gramer" → "grammar"
        return text

    def postprocess_text(self, corrected_text):
        # Correct any remaining or misapplied changes
        corrected_text = corrected_text.replace("Kramer", "grammar")  # Fix "Kramer" → "grammar"
        return corrected_text


if __name__ == "__main__":
    corrector = GrammarCorrector()  # Initialize grammar corrector

    # Input text with errors
    text = """This is a exmple of a bad gramer. 
    The quick brown fox jump over the lazy dog.
    She dont like icecream but loves chocolatte.
    He have been working hear since yesterday."""

    print("\nOriginal Text:")
    print(text)

    # Correct the text
    corrected_text, errors = corrector.correct(text)

    print("\nCorrected Text:")
    print(corrected_text)

    print("\nDetected Errors:")
    for error in errors:
        print(f"- {error['message']}")
        print(f"  Context: {error['context']}")
        print(f"  Suggestions: {', '.join(error['suggestions'])}")

