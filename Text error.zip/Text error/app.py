from flask import Flask, request, jsonify, render_template
from grammar_corrector import GrammarCorrector
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs('corrected_files', exist_ok=True)

# Initialize GrammarCorrector
corrector = GrammarCorrector()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/correct', methods=['POST'])
def correct_text():
    try:
        data = request.json
        input_text = data.get('text', '')
        corrected_text, errors = corrector.correct(input_text)
        return jsonify({'corrected_text': corrected_text, 'errors': errors})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files['file']
    if file and file.filename.endswith('.txt'):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        with open(file_path, 'r') as f:
            content = f.read()
        corrected_content, _ = corrector.correct(content)
        corrected_file_path = os.path.join('corrected_files', f'corrected_{file.filename}')
        with open(corrected_file_path, 'w') as f:
            f.write(corrected_content)
        return jsonify({'corrected_file': corrected_file_path})
    return jsonify({'error': 'Invalid file type'}), 400

if __name__ == '__main__':
    app.run(debug=True)
