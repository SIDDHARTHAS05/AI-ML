# Grammar Error Correction Application

This application detects and corrects grammatical errors in text using Flask and the `language_tool_python` library.

## Features

- Corrects grammatical errors in manually entered text.
- Allows batch correction of `.txt` files.
- Displays corrected text or downloads corrected files.

## Installation

1. Clone the repository:
   ```
   git clone <repository_url>
   cd grammar_error_correction
   ```
2. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\\Scripts\\activate
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Run the application:
   ```
   python app.py
   ```

## Usage

1. Open your browser and navigate to `http://127.0.0.1:5000/`.
2. Use the text area for text correction or upload `.txt` files for batch correction.

## Dependencies

- Flask
- language-tool-python

## License

This project is licensed under the MIT License.
