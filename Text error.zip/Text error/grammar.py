import language_tool_python

# Connect to the running LanguageTool server
tool = language_tool_python.LanguageToolPublicAPI('http://localhost:8081')

# Sample text
text = "This are a example of bad gramer."
matches = tool.check(text)

# Correct the text
corrected_text = language_tool_python.utils.correct(text, matches)

# Print the results
print("Corrected Text:", corrected_text)

# Print the matches
for match in matches:
    print(f"Issue: {match.message}")
    print(f"Suggestions: {', '.join(match.replacements)}")

# Stop the server after processing (optional)
# server_process.terminate()
